<?php $this->beginContent('/layouts/header'); ?>
<?php $this->endContent(); ?>

 <?php echo $content;?>

<?php $this->beginContent('/layouts/footer'); ?>
<?php $this->endContent(); ?>
