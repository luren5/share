<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>爱分享——后台管理</title>
<link rel="stylesheet" href="<?php echo ADMIN_CSS_URL;?>table.css" type="text/css">
<link href="<?php echo ADMIN_CSS_URL?>bootstrap.min.css" type="text/css" rel="stylesheet">
<body>