<div class="well block noreply">
     <h4>关注新浪微博</h4>
     <a href="http://weibo.com/u/3915153185" target="_blank">
        <img src="<?php echo IMG_URL; ?>weibo_32.png">
        @爱分享-正能量
     </a>
</div>

