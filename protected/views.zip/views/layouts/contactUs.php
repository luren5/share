<div class="well block noreply">
    <h4>联系我们</h4>
    <a target="_blank" href="<?php echo $this->createUrl('feedback/index') ?>" style="text-decoration:none;">
        <img src="<?php echo IMG_URL?>mail.png">
    </a>
</div>