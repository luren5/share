<div class="well block noreply">
     <h4>站内搜索</h4>   
     <br/>
    <form class="form-search" action="<?php echo $this->createUrl('resource/search') ?>" method="post">
        <div class="input-append">
            <input type="text" name ="key"  placeholder="请输入关键词" class="span9 search-query">
            <button type="submit" class="btn">Search</button>
        </div>
</form>
</div>
