 <footer class="global-footer">
     <span>© Copyright 2013. 湖工大在线 爱分享</span>
     <br>
     <a target="_blank" href="http://weibo.com/u/3915153185">关注我们</a>｜<a target="_blank" href="<?php echo $this->createUrl('feedback/index') ?>">意见反馈</a>
     <br>
     友情链接：<a target="_blank" href="http://bbs.hgdonline.net">南湖呓语</a>｜<a target="_blank" href="http://news.hgdonline.net">湖工大新闻网</a>
 </footer>
    <script src="<?php echo JS_URL?>jquery-1.7.2.min.js"></script>
    <script src="<?php echo JS_URL?>jquery.tmpl.min.js"></script>
  </body>
</html>