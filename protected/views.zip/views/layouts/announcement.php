<div class="well block noreply">
    <h4>站点公告</h4>
    <p>人生已经如此的艰难，有些事情就不必拆穿！</p>
    <p>人生已经如此的艰难，有些事情就不必拆穿！</p>
</div>