<div class="well block noreply">
     <h4>扫一扫，关注微信</h4>
     <img src="<?php echo IMG_URL; ?>test_wein.jpg">
</div>
