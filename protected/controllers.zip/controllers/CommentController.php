<?php
    class CommentController extends Controller
    {
        public function actionLast() {

        }
    }